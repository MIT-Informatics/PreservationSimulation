#
sInputFilename <- "./q2-d50a1000s1h10-output-01.txt"
sOutputFilename <- "./q2-d50a1000s1h10-TotalAuditMonthly-analysis-01.txt"
sTitle <- "Q2 Monthly total audit"
source("./ShelfAnalyze-01.r")

