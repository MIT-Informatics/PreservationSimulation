#
sInputFilename <- "./q2-d50a2500s1-output-01.txt"
sOutputFilename <- "./q2-d50a2500s1-TotalAuditQuarterly-analysis-01.txt"
sTitle <- "Q2 Quarterly total audit"
source("./ShelfAnalyze-01.r")

