echo `expr $2 - $1`
