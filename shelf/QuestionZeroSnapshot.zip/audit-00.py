#!/usr/bin/python
# audit.py
#

''' TODO:
    x- Put bandwidth into G.
    x- Put hours conversion const into G.
    - Put audit frequency into G.
    x- Add Server to specificity of Audit.
    x- Add traces.
    - Use docs only, not copies.  Clients don't know copies.  
'''
'''
audit cycle invoked once every x hours:
    foreach client
        foreach collection
            foreach document
                retrieve doc from server
                if doc still exists
                    wait time to retrieve doc rel to size
                    compare with original doc
                    (always success now)
                else
                    repair by sending new copy of doc
                    wait time to send doc rel to size
                
need one async process per client to schedule audit cycles.
need one async process for retrieving doc from server
and for replacing doc in server, since they share bandwidth.

const for interval between audits
const for speed of network while transmitting docs
const for second of time

client creates an audit object for collection
that init starts an async process for the auditing
wait for a random time, so that all client audits do not happen simultaneously
when audit cycle done, wait for standard interval
'''

from globaldata import G
import itertools
from util import makeunif
from NewTraceFac import TRC,trace,tracef


# c l a s s   C A u d i t 
class CAudit(object):
    ''' Procedures for auditing collections kept on 
        remote servers.  Clients will create one instance
        of this class for each collection on each server.  
        Collection audits run asynchronously.  
    '''
    getID = itertools.count(1).next

    @tracef("AUD")
    def __init__(self,mysClientID,mysCollectionID,mysServerID,mynInterval=G.nAuditCycleInterval):
        self.ID = "A" + str(self.getID())
        self.sClientID = mysClientID
        self.sServerID = mysServerID
        self.sCollectionID = mysCollectionID
        self.nCycleInterval = mynInterval
        # Start the free-running process of audit cycles for 
        # this collection.
        G.env.process(self.mAuditCycle(self.nCycleInterval))

        # TEMP TEMP TEMP TEMP TEMP TEMP
        G.nAuditCycleInterval = 10000
        G.nBandwidthMbps = 10
        G.fSecondsPerHour = float(60*60)
        # END TEMP END TEMP END TEMP END

    # C A u d i t . m A u d i t C y c l e 
    @tracef("AUD")
    def mAuditCycle(self,mynInterval):
        ''' Generator to schedule audit cycles for this collection.
            Starts an async process that ticks every 
            audit cycle forever.
        '''
        # Initially, wait for some small random interval
        # so that client audit cycles are not synchronized. 
        nRandTime = makeunif(0,mynInterval/2)
        yield G.env.timeout(nRandTime)
        
        while True:
            yield G.env.timeout(mynInterval)
            G.env.process(self.mAuditCollection(mysCollectionID))

    # C A u d i t . m A u d i t C o l l e c t i o n 
    @tracef("AUD")
    def mAuditCollection(self,mysCollectionID):
        ''' Audit an entire collection.
            foreach copy in the collection
                audit copy
                retrieve copy from server
                if copy still exists
                    wait time to retrieve copy rel to size
                    compare with original doc
                    (always success now)
                else
                    repair copy

        '''
        cCollection = G.dID2Collection[mysCollectionID]
        lDocIDs = cCollection.mListDocuments()
        for sDocID in lDocIDs:
            fTransferTime = self.mRetrieveCopy(sDocID)
            if fTransferTime:
                yield G.env.timeout(fTransferTime)
                # Here we would test the document contents
                # for validity, that is, if our documents
                # had contents.  
            else:
                fTransferTime = self.mRepairCopy(sDocID)
                yield G.env.timeout(fTransferTime)

    # C A u d i t . m R e t r i e v e C o p y 
    
    @tracef("AUD")
    def mRetrieveCopy(self,mysCopyID):
        ''' Get copy back from server, if possible.
            Return the time required to transmit the doc.
            Ideally, would wait for transmission time, 
            but the waiting has to occur in the 
            parent loop.  
        '''
        cCopy = G.dID2Copy[mysCopyID]
        sDocID = cCopy.sDocID
        cDoc = G.dID2Doc[sDocID]
        nDocSize = cDoc.nSize
        fTransferTime = self.mCalcTransferTime(nDocSize,G.nBandwidthMb)
        # Now that we know how long it would take to transfer,
        # test if the document is still there.  
        bResult = cDoc.mDocTestOneServer(self.sServerID)
        if bResult:
            return fTransferTime
        else:
            return None

    # C A u d i t . m R e p a i r C o p y 
    @tracef("AUD")
    def mRepairCopy(self,mysDocID,mysCopyID):
        ''' Repair copy by sending new copy of original doc
            to the server.  
            Return the time required to transmit the doc.
            Ideally, the wait time to send doc rel to size
            would occur here, but it occurs in the parent loop.
        '''
        cCopy = G.dID2Copy[mysCopyID]
        sDocID = cCopy.sDocID
        cDoc = G.dID2Doc[sDocID]
        nDocSize = cDoc.nSize
        fTransferTime = self.mCalcTransferTime(nDocSize,G.nBandwidthMbps)
        return fTransferTime

    # C A u d i t . m C a l c T r a n s f e r T i m e 
    @tracef("AUD",level=5)
    def mCalcTransferTime(self,mynDocSize,mynBandwidth):
        ''' Convert doc size in MB and bandwidth in Mb/s 
            to part of an hour that it takes to transmit.  
        '''
        fPartialHours = float(mynDocSize)   \
        * 10                                \
        / float(mynBandwidth)               \
        / float(G.fSecondsPerHour)
        return fPartialHours

