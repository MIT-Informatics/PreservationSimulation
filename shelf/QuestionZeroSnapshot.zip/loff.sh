unset LOG_LEVEL
